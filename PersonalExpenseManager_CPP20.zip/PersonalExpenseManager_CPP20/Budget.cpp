#include "Budget.h"
#include "BudgetExceededException.h"
void Budget::checkLimit(double spent) const {
    if(spent > limit) throw BudgetExceededException("Monthly budget exceeded", spent-limit);
}
