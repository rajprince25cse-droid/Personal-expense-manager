#include "FileManager.h"
#include <fstream>
#include <filesystem>
using namespace std;

void FileManager::save(const vector<User>& u,const vector<Category>& c,const vector<Expense>& e,const vector<Budget>& b) const {
    filesystem::create_directories(dir);
    ofstream fu(dir+"/users.txt"), fc(dir+"/categories.txt"), fe(dir+"/expenses.txt"), fb(dir+"/budgets.txt");
    if(!fu||!fc||!fe||!fb) throw runtime_error("Could not open data files for saving");
    for(const auto& x:u) fu<<x.serialize()<<'\n';
    for(const auto& x:c) fc<<x.serialize()<<'\n';
    for(const auto& x:e) fe<<x.serialize()<<'\n';
    for(const auto& x:b) fb<<x.serialize()<<'\n';
}
void FileManager::loadLines(const string& path, vector<string>& lines) {
    ifstream f(path); string s; while(getline(f,s)) if(!s.empty()) lines.push_back(s);
}
void FileManager::load(vector<User>& u,vector<Category>& c,vector<Expense>& e,vector<Budget>& b) {
    filesystem::create_directories(dir);
    vector<string> lines;
    loadLines(dir+"/users.txt",lines);
    for(auto& s:lines) try { User x; x.deserialize(s); u.push_back(x); } catch(...) {}
    lines.clear(); loadLines(dir+"/categories.txt",lines);
    for(auto& s:lines) try { Category x; x.deserialize(s); c.push_back(x); } catch(...) {}
    lines.clear(); loadLines(dir+"/expenses.txt",lines);
    for(auto& s:lines) try { Expense x; x.deserialize(s); e.push_back(x); } catch(...) {}
    lines.clear(); loadLines(dir+"/budgets.txt",lines);
    for(auto& s:lines) try { Budget x; x.deserialize(s); b.push_back(x); } catch(...) {}
}
