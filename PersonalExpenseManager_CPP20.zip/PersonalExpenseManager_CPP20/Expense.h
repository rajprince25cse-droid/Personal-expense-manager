#ifndef EXPENSE_H
#define EXPENSE_H
#include "Entity.h"
#include <iomanip>

class Expense : public Entity {
    int userId, categoryId;
    double amount;
    string date;
public:
    Expense() : userId(0), categoryId(0), amount(0) {}
    Expense(int i,int u,int c,double a,string d) : Entity(i), userId(u), categoryId(c), amount(a), date(d) {
        if(i<=0 || u<=0 || c<=0 || a<=0) throw invalid_argument("IDs and amount must be positive");
        if(d.size()!=10 || d[4]!='-' || d[7]!='-') throw invalid_argument("Date must use YYYY-MM-DD");
    }
    int getUserId() const { return userId; }
    int getCategoryId() const { return categoryId; }
    double getAmount() const { return amount; }
    string getDate() const { return date; }
    string getMonth() const { return date.substr(0,7); }
    void setAmount(double a) { if(a<=0) throw invalid_argument("Amount must be greater than zero"); amount=a; }
    void setDate(const string& d) { if(d.size()!=10 || d[4]!='-' || d[7]!='-') throw invalid_argument("Date must use YYYY-MM-DD"); date=d; }
    void display() const override {
        cout << id << "\t" << userId << "\t" << categoryId << "\t"
             << fixed << setprecision(2) << amount << "\t" << date << '\n';
    }
    string serialize() const override {
        return to_string(id)+"|"+to_string(userId)+"|"+to_string(categoryId)+"|"+to_string(amount)+"|"+date;
    }
    void deserialize(const string& s) override {
        size_t a=s.find('|'), b=s.find('|',a+1), c=s.find('|',b+1), d=s.find('|',c+1);
        if(a==string::npos||b==string::npos||c==string::npos||d==string::npos) throw runtime_error("Bad expense record");
        id=stoi(s.substr(0,a)); userId=stoi(s.substr(a+1,b-a-1));
        categoryId=stoi(s.substr(b+1,c-b-1)); amount=stod(s.substr(c+1,d-c-1));
        setDate(s.substr(d+1));
        if(id<=0||userId<=0||categoryId<=0||amount<=0) throw runtime_error("Invalid expense record");
    }
};
#endif
