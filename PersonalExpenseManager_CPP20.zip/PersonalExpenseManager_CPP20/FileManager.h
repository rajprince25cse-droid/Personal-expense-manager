#ifndef FILE_MANAGER_H
#define FILE_MANAGER_H
#include <string>
#include <vector>
#include "User.h"
#include "Category.h"
#include "Expense.h"
#include "Budget.h"
using namespace std;

class FileManager {
    string dir;
    void loadLines(const string&, vector<string>&);
public:
    FileManager(string d="Data") : dir(d) {}
    void save(const vector<User>&, const vector<Category>&, const vector<Expense>&, const vector<Budget>&) const;
    void load(vector<User>&, vector<Category>&, vector<Expense>&, vector<Budget>&);
};
#endif
