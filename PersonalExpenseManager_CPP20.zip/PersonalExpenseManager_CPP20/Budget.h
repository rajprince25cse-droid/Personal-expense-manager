#ifndef BUDGET_H
#define BUDGET_H
#include "Entity.h"

class Budget : public Entity {
    int categoryId;
    double limit;
    string month;
public:
    Budget() : categoryId(0), limit(0) {}
    Budget(int i,int c,double l,string m) : Entity(i), categoryId(c), limit(l), month(m) {
        if(i<=0||c<=0||l<=0) throw invalid_argument("IDs and budget must be positive");
        if(m.size()!=7 || m[4]!='-') throw invalid_argument("Month must use YYYY-MM");
    }
    int getCategoryId() const { return categoryId; }
    double getLimit() const { return limit; }
    string getMonth() const { return month; }
    void checkLimit(double spent) const;
    void display() const override { cout << id << "\t" << categoryId << "\t" << limit << "\t" << month << '\n'; }
    string serialize() const override { return to_string(id)+"|"+to_string(categoryId)+"|"+to_string(limit)+"|"+month; }
    void deserialize(const string& s) override {
        size_t a=s.find('|'),b=s.find('|',a+1),c=s.find('|',b+1);
        if(a==string::npos||b==string::npos||c==string::npos) throw runtime_error("Bad budget record");
        id=stoi(s.substr(0,a)); categoryId=stoi(s.substr(a+1,b-a-1));
        limit=stod(s.substr(b+1,c-b-1)); month=s.substr(c+1);
        if(id<=0||categoryId<=0||limit<=0||month.size()!=7||month[4]!='-') throw runtime_error("Invalid budget record");
    }
};
#endif
