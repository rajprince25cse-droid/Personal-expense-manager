#ifndef ENTITY_H
#define ENTITY_H
#include <iostream>
#include <string>
using namespace std;

class Entity {
protected:
    int id;
public:
    Entity(int i = 0) : id(i) {}
    virtual ~Entity() {}
    int getId() const { return id; }
    virtual void display() const = 0;
    virtual string serialize() const = 0;
    virtual void deserialize(const string&) = 0;
};
#endif
