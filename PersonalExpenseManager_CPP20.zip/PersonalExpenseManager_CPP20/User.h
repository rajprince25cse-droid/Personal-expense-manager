#ifndef USER_H
#define USER_H
#include "Entity.h"

class User : public Entity {
    string name;
public:
    User() {}
    User(int i, string n) : Entity(i), name(n) {}
    string getName() const { return name; }
    void setName(const string& n) { if (n.empty() || n.find('|') != string::npos) throw invalid_argument("Invalid name"); name=n; }
    void display() const override { cout << id << "\t" << name << '\n'; }
    string serialize() const override { return to_string(id)+"|"+name; }
    void deserialize(const string& s) override {
        size_t p=s.find('|'); if(p==string::npos) throw runtime_error("Bad user record");
        id=stoi(s.substr(0,p)); setName(s.substr(p+1));
    }
};
#endif
