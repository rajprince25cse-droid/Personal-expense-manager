#ifndef CATEGORY_H
#define CATEGORY_H
#include "Entity.h"

class Category : public Entity {
    string name;
public:
    Category() {}
    Category(int i, string n) : Entity(i), name(n) {}
    string getName() const { return name; }
    void setName(const string& n) { if(n.empty() || n.find('|')!=string::npos) throw invalid_argument("Invalid category name"); name=n; }
    void display() const override { cout << id << "\t" << name << '\n'; }
    string serialize() const override { return to_string(id)+"|"+name; }
    void deserialize(const string& s) override {
        size_t p=s.find('|'); if(p==string::npos) throw runtime_error("Bad category record");
        id=stoi(s.substr(0,p)); setName(s.substr(p+1));
    }
};
#endif
