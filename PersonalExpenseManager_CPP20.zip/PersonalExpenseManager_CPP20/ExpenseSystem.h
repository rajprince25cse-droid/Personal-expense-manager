#ifndef EXPENSE_SYSTEM_H
#define EXPENSE_SYSTEM_H
#include <vector>
#include "User.h"
#include "Category.h"
#include "Expense.h"
#include "Budget.h"
#include "FileManager.h"
using namespace std;

class ExpenseSystem {
    vector<User> users;
    vector<Category> categories;
    vector<Expense> expenses;
    vector<Budget> budgets;
    FileManager files;
    bool hasId(int, int) const;
    bool userExists(int) const;
    bool categoryExists(int) const;
    string categoryName(int) const;
    string userName(int) const;
    double spent(int,const string&,int skipId=0) const;
    void save();
    void addUser();
    void addCategory();
    void addExpense(bool budgetCheck);
    void addBudget();
    void display();
    void search();
    void update();
    void removeRecord();
    void report();
public:
    ExpenseSystem();
    void run();
};
#endif
