#ifndef BUDGET_EXCEEDED_EXCEPTION_H
#define BUDGET_EXCEEDED_EXCEPTION_H
#include <exception>
#include <string>
using namespace std;

class BudgetExceededException : public exception {
    string message;
    double exceededBy;
public:
    BudgetExceededException(string m,double e) : message(m), exceededBy(e) {}
    const char* what() const noexcept override { return message.c_str(); }
    double getExceededBy() const { return exceededBy; }
};
#endif
