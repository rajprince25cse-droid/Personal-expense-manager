# Personal Expense Manager (C++ / CPP20)

A menu-driven C++17 console application for managing users, expense categories, expenses, monthly budgets, and monthly reports. Data is saved in text files in the `Data/` directory.

## Features
- Add users and categories
- Record expenses with positive amounts and basic date-format validation
- Set monthly category budgets
- Display, search, update, and delete records
- Warn about budget overruns in the dedicated budget-check transaction
- Generate a monthly category-wise report and grand total
- Save/load records automatically

## Compile
From this folder, run:

```bash
g++ -std=c++17 -Wall -Wextra main.cpp ExpenseSystem.cpp FileManager.cpp Budget.cpp -o ExpenseManager
```

## Run
- Windows: `ExpenseManager.exe`
- Linux/macOS: `./ExpenseManager`

Keep the `Data/` folder beside the executable/current working directory. It is created automatically.

## Notes
This is a working educational implementation aligned with the Personal Expense Manager topic. It uses `std::vector` for collections to keep record management clear and safe; if your instructor requires the exact raw-pointer dynamic-array design described in the report, that implementation detail should be changed before submission. Date validation checks the YYYY-MM-DD shape, not every calendar-date edge case.
