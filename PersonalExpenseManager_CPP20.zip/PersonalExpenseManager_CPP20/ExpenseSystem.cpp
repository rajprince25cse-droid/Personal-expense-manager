#include "ExpenseSystem.h"
#include "BudgetExceededException.h"
#include <iostream>
#include <iomanip>
#include <limits>
using namespace std;

ExpenseSystem::ExpenseSystem() { files.load(users,categories,expenses,budgets); }
bool ExpenseSystem::hasId(int id,int type) const {
    if(type==1) for(auto& x:users) if(x.getId()==id)return true;
    if(type==2) for(auto& x:categories) if(x.getId()==id)return true;
    if(type==3) for(auto& x:expenses) if(x.getId()==id)return true;
    if(type==4) for(auto& x:budgets) if(x.getId()==id)return true;
    return false;
}
bool ExpenseSystem::userExists(int id) const { for(auto& x:users)if(x.getId()==id)return true; return false; }
bool ExpenseSystem::categoryExists(int id) const { for(auto& x:categories)if(x.getId()==id)return true; return false; }
string ExpenseSystem::categoryName(int id) const { for(auto& x:categories)if(x.getId()==id)return x.getName(); return "Unknown"; }
string ExpenseSystem::userName(int id) const { for(auto& x:users)if(x.getId()==id)return x.getName(); return "Unknown"; }
double ExpenseSystem::spent(int cat,const string& month,int skipId) const {
    double total=0; for(auto& x:expenses) if(x.getCategoryId()==cat&&x.getMonth()==month&&x.getId()!=skipId) total+=x.getAmount(); return total;
}
void ExpenseSystem::save() { files.save(users,categories,expenses,budgets); }
static int readInt(const string& prompt) {
    int x; cout<<prompt;
    while(!(cin>>x)){ cout<<"Invalid number. Try again: "; cin.clear(); cin.ignore(numeric_limits<streamsize>::max(),'\n'); }
    cin.ignore(numeric_limits<streamsize>::max(),'\n'); return x;
}
static string readText(const string& prompt) { string s; cout<<prompt; getline(cin,s); return s; }
static double readDouble(const string& prompt) {
    double x; cout<<prompt;
    while(!(cin>>x)){ cout<<"Invalid amount. Try again: "; cin.clear(); cin.ignore(numeric_limits<streamsize>::max(),'\n'); }
    cin.ignore(numeric_limits<streamsize>::max(),'\n'); return x;
}
void ExpenseSystem::addUser() {
    int id=readInt("User ID: "); if(id<=0||hasId(id,1)) throw invalid_argument("ID must be positive and unique");
    string n=readText("Name: "); if(n.empty()||n.find('|')!=string::npos) throw invalid_argument("Invalid name");
    users.emplace_back(id,n); save(); cout<<"User added.\n";
}
void ExpenseSystem::addCategory() {
    int id=readInt("Category ID: "); if(id<=0||hasId(id,2)) throw invalid_argument("ID must be positive and unique");
    string n=readText("Category name (e.g. Food): "); if(n.empty()||n.find('|')!=string::npos) throw invalid_argument("Invalid category name");
    categories.emplace_back(id,n); save(); cout<<"Category added.\n";
}
void ExpenseSystem::addExpense(bool budgetCheck) {
    int id=readInt("Expense ID: "),u=readInt("User ID: "),c=readInt("Category ID: ");
    double a=readDouble("Amount (Rs.): "); string d=readText("Date (YYYY-MM-DD): ");
    if(id<=0||hasId(id,3)) throw invalid_argument("Expense ID must be positive and unique");
    if(!userExists(u)||!categoryExists(c)) throw invalid_argument("User ID or category ID does not exist");
    Expense x(id,u,c,a,d);
    if(budgetCheck) {
        for(const auto& b:budgets) if(b.getCategoryId()==c&&b.getMonth()==x.getMonth()) {
            try { b.checkLimit(spent(c,x.getMonth())+a); }
            catch(const BudgetExceededException& ex) {
                cout<<"WARNING: "<<ex.what()<<" by Rs. "<<fixed<<setprecision(2)<<ex.getExceededBy()<<'\n';
                string ans=readText("Record anyway? (y/n): ");
                if(ans!="y"&&ans!="Y") { cout<<"Expense cancelled.\n"; return; }
            }
            break;
        }
    }
    expenses.push_back(x); save(); cout<<"Expense recorded.\n";
}
void ExpenseSystem::addBudget() {
    int id=readInt("Budget ID: "),c=readInt("Category ID: "); double l=readDouble("Monthly limit (Rs.): ");
    string m=readText("Month (YYYY-MM): ");
    if(id<=0||hasId(id,4)) throw invalid_argument("Budget ID must be positive and unique");
    if(!categoryExists(c)) throw invalid_argument("Category does not exist");
    for(auto& b:budgets) if(b.getCategoryId()==c&&b.getMonth()==m) throw invalid_argument("Budget already exists for this category and month");
    budgets.emplace_back(id,c,l,m); save(); cout<<"Budget added.\n";
}
void ExpenseSystem::display() {
    cout<<"\nUSERS\nID\tName\n"; for(auto& x:users)x.display();
    cout<<"\nCATEGORIES\nID\tName\n"; for(auto& x:categories)x.display();
    cout<<"\nEXPENSES\nID\tUser\tCategory\tAmount\tDate\n"; for(auto& x:expenses)x.display();
    cout<<"\nBUDGETS\nID\tCategory\tLimit\tMonth\n"; for(auto& x:budgets)x.display();
}
void ExpenseSystem::search() {
    int id=readInt("Enter expense ID: "); bool found=false;
    cout<<"ID\tUser\tCategory\tAmount\tDate\n";
    for(auto& x:expenses) if(x.getId()==id) { x.display(); found=true; }
    if(!found) cout<<"Expense not found.\n";
}
void ExpenseSystem::update() {
    int id=readInt("Expense ID to update: ");
    for(auto& x:expenses) if(x.getId()==id) {
        double a=readDouble("New amount: "); string d=readText("New date (YYYY-MM-DD): ");
        x.setAmount(a); x.setDate(d); save(); cout<<"Expense updated.\n"; return;
    }
    cout<<"Expense not found.\n";
}
void ExpenseSystem::removeRecord() {
    cout<<"Delete: 1 User  2 Category  3 Expense  4 Budget\n";
    int t=readInt("Type: "),id=readInt("ID: ");
    if(t==1) {
        for(auto& e:expenses) if(e.getUserId()==id) throw invalid_argument("Cannot delete a user referenced by expenses");
        for(size_t i=0;i<users.size();++i) if(users[i].getId()==id){users.erase(users.begin()+i);save();cout<<"Deleted.\n";return;}
    } else if(t==2) {
        for(auto& e:expenses) if(e.getCategoryId()==id) throw invalid_argument("Cannot delete a category referenced by expenses");
        for(auto& b:budgets) if(b.getCategoryId()==id) throw invalid_argument("Cannot delete a category referenced by budgets");
        for(size_t i=0;i<categories.size();++i) if(categories[i].getId()==id){categories.erase(categories.begin()+i);save();cout<<"Deleted.\n";return;}
    } else if(t==3) {
        for(size_t i=0;i<expenses.size();++i) if(expenses[i].getId()==id){expenses.erase(expenses.begin()+i);save();cout<<"Deleted.\n";return;}
    } else if(t==4) {
        for(size_t i=0;i<budgets.size();++i) if(budgets[i].getId()==id){budgets.erase(budgets.begin()+i);save();cout<<"Deleted.\n";return;}
    }
    cout<<"Record not found.\n";
}
void ExpenseSystem::report() {
    string m=readText("Report month (YYYY-MM): "); double grand=0;
    cout<<"\nMONTHLY REPORT: "<<m<<"\nCategory\tBudget\tSpent\tRemaining\tStatus\n";
    for(auto& c:categories) {
        double limit=0; bool has=false;
        for(auto& b:budgets) if(b.getCategoryId()==c.getId()&&b.getMonth()==m){limit=b.getLimit();has=true;}
        double s=spent(c.getId(),m); grand+=s;
        cout<<c.getName()<<'\t';
        if(has) cout<<fixed<<setprecision(2)<<limit<<'\t'<<s<<'\t'<<limit-s<<'\t'<<(s>limit?"EXCEEDED":"OK")<<'\n';
        else cout<<"No budget\t"<<fixed<<setprecision(2)<<s<<"\t-\tNOT SET\n";
    }
    cout<<"Grand total spent: Rs. "<<fixed<<setprecision(2)<<grand<<'\n';
}
void ExpenseSystem::run() {
    int ch;
    do {
        cout<<"\n=================================\n PERSONAL EXPENSE MANAGER\n=================================\n"
            <<"1. Add User\n2. Add Category\n3. Add Expense\n4. Set Monthly Budget\n"
            <<"5. Display All Records\n6. Search Expense\n7. Update Expense\n"
            <<"8. Delete Record\n9. Monthly Report\n10. Save Data\n0. Exit\n";
        ch=readInt("Choice: ");
        try {
            switch(ch) {
                case 1:addUser();break;
                case 2:addCategory();break;
                case 3:addExpense(true);break;
                case 4:addBudget();break;
                case 5:display();break;
                case 6:search();break;
                case 7:update();break;
                case 8:removeRecord();break;
                case 9:report();break;
                case 10:save();cout<<"Data saved.\n";break;
                case 0:save();cout<<"Data saved. Goodbye!\n";break;
                default:cout<<"Invalid choice.\n";
            }
        } catch(const exception& e) { cout<<"Error: "<<e.what()<<'\n'; }
    } while(ch!=0);
}
